# budget-cli

## description
a simple python and supabase cli. i kind of have a spending problem but i can't possibly be bothered to download a budgeting app or use a spreadsheet. however i'm always using my terminal so i thought this would be an easy way for me to log things without being overwhelmed by the UI

### usage
available commands:
1. default `--version` and `--help`

## technologies
- the cli itself is built with python
- supabase is used for storing all of the fields that i need